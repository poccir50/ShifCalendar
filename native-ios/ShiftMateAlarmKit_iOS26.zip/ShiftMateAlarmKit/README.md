# ShiftMate AlarmKit iPhone App

A조 교대근무를 계산해 **주간 근무일에만 실제 iPhone AlarmKit 알람**을 예약하는 네이티브 iOS 앱입니다.

## 기본값
- 기준 주: 2026-08-10 ~ 08-14 = A조 주간
- 매주 주간/야간 교대
- 주말 휴무
- 주간: 06:45~15:30
- 야간: 15:35~00:20
- 기상: 04:50
- 2026 회사휴무 내장

## 주요 기능
- AlarmKit 권한 요청
- 주간 근무일 04:50 실제 알람 예약
- 야간/주말/회사휴무 자동 제외
- 15초 테스트 알람
- 사용자 오디오 파일을 `Library/Sounds`로 가져와 AlarmKit custom sound로 사용
- 시스템 예약 한도에 도달하면 가능한 수만큼 예약하고 이후 앱 실행 때 재동기화

## 설치에 필요한 것
이 소스는 iOS 26+ / Xcode 26+용입니다. **iPhone 네이티브 앱은 Apple 코드서명이 필수**라 GitHub Pages처럼 URL만 눌러 설치할 수 없습니다.

1. Mac의 Xcode 26+에서 `ShiftMateAlarm.xcodeproj`를 엽니다.
2. Target → Signing & Capabilities에서 본인의 Team을 선택합니다.
3. 연결한 iPhone을 실행 대상에 선택하고 Run 합니다.
4. 앱에서 `알람 권한 허용` → `근무표 기준 알람 다시 동기화`를 누릅니다.
5. 먼저 `15초 뒤 테스트 알람`으로 실제 소리/잠금화면 동작을 확인하세요.

무료 Apple ID의 개인 개발 서명은 설치 유지기간에 제약이 있을 수 있습니다. 장기 배포는 Apple Developer Program/TestFlight/App Store 배포가 가장 안정적입니다.

## 사용자 알람음
Clock 앱에 이미 설정된 벨소리를 다른 앱이 읽는 API는 없습니다. 대신 앱의 `Files에서 알람음 가져오기`로 오디오 파일을 가져와 AlarmKit의 named sound로 사용합니다. Apple 문서상 custom sound는 앱 번들이나 `Library/Sounds`에 둘 수 있습니다.

## 2027년
회사 2027 캘린더가 아직 입력되지 않았으므로 자동 예약은 2026-12-31까지로 제한했습니다. 2027 회사 달력을 받으면 `ShiftEngine.swift`의 휴무 데이터를 추가하면 됩니다.
